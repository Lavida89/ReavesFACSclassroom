# 👩‍🏫 About Ms. Reaves

Hi! I’m **Ms. LaVida Reaves**, and I’m proud to be your Family and Consumer Sciences teacher at **Hugh M. Cummings High School**.

I hold a **Bachelor’s degree in Child Development Education** and am currently pursuing my **Master’s in Family and Consumer Sciences**. I’ve been teaching here for **5 years**, and I’m passionate about helping students develop real-life skills in wellness, finance, child care, and more.

📧 **Email:** [lreaves@aggies.ncat.edu](mailto:lreaves@aggies.ncat.edu)  
🕒 **Study Hall:** Tuesdays & Thursdays, 3:45–4:45 PM
