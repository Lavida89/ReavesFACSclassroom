# 📋 Class Rules and Guidelines

**Respect**: Treat yourself, classmates, and our learning space kindly.  
**Be Prepared**: Bring materials, complete homework, and be ready to participate.  
**Engage**: Ask questions, collaborate, and stay involved.  

**Technology Use:**  
- Phones away during instruction  
- Chromebooks for classwork only

**Late Work Policy:**  
- 5-day window with 10% penalty per day  
- Make-up work allowed with communication
