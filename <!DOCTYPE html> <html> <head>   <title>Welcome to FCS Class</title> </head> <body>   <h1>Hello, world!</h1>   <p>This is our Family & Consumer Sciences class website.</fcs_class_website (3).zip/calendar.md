# 📅 Class Calendar

| Date     | Event                        |
|----------|------------------------------|
| Aug 21   | First Day of School          |
| Sep 2    | **Labor Day – No Class**     |
| Oct 14   | **Unit 1 Project Due**       |
| Nov 25   | Family Meal Planning Activity |

> 📌 _Calendar will be updated regularly._
