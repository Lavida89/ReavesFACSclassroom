# 👩‍🏫 Family and Consumer Sciences

Welcome to our class site! Use the links below to explore:

- [📅 Class Calendar](calendar.md)
- [📋 Rules and Guidelines](rules.md)
- [📣 Announcements & Events](announcements.md)
- [👩‍🏫 About Ms. Reaves](about.md)
- [📘 Course Overview](overview.md)
