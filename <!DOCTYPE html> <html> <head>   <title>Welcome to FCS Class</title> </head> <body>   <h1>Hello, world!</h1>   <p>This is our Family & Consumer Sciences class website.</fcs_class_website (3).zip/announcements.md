# 📣 Announcements & Events

- 🎉 Congrats to the Nutrition Challenge winners!  
- 📅 Parent Night: October 10 at 6 PM  
- 🧪 Quiz Alert: Kitchen Safety Quiz this Friday

> Check here weekly for new updates.
