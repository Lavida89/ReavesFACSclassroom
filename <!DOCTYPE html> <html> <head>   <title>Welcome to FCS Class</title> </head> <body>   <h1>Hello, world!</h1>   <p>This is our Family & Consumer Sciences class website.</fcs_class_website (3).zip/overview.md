# 📘 Course Overview

**Family & Consumer Sciences** introduces students to skills for independent and healthy living.

## 🧠 Topics Covered
- 🍽️ Nutrition & Meal Prep  
- 👶 Child Development  
- 💰 Personal Finance & Budgeting  
- 🧳 Career Readiness  
- 🧼 Safety & Sanitation in the Kitchen  

Expect engaging labs, hands-on projects, and collaboration!
